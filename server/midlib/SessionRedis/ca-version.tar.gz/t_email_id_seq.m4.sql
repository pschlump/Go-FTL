
-- "Copyright (C) Philip Schlump, 2009-2017." 

-- drop SEQUENCE t_email_id_seq;

CREATE SEQUENCE t_email_id_seq
  INCREMENT 1
  MINVALUE 10000
  MAXVALUE 9223372036854775807
  START 10000
  CACHE 1;

