
-- CREATE or REPLACE FUNCTION s_echo_builtin(p_ip_addr varchar, p_url varchar, p_host varchar)
select s_echo_builtin('1.1.1.1', 'http://auth.2c-why.com/', 'host???');

