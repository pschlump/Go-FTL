
-- "Copyright (C) Philip Schlump, 2019." 

m4_include(types.m4)

CREATE TABLE "t_auth_log" (
	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
  	, "user_id" 			char varying (40) not null			 						
	, "outcome"				text not null
	, "updated" 			timestamp 									 						
	, "created" 			timestamp default current_timestamp not null 					
);

m4_updTrig(t_auth_log)

