
select s_setup_customer ( '127.0.0.1', '2' );

-- set "htci:lonetree-ranch.beefchain.com" "2"
-- 
-- set "htci:192.154.97.75:9017" "2"
-- set "htci:192.154.97.75:9019" "2"
-- set "htci:192.154.97.75:9021" "2"
-- set "htci:192.154.97.75:9023" "2"
-- set "htci:192.154.97.75:9025" "2"
-- set "htci:192.154.97.75:9027" "2"
-- set "htci:192.154.97.75:9029" "2"
-- 
-- set "htci:2fa.agroledge.com:9017" "2"
-- set "htci:auth.agroledge.com:9019" "2"
-- set "htci:email.agroledge.com:9021" "2"
-- set "htci:livemon.agroledge.com:9023" "2"
-- set "htci:qrgen.agroledge.com:9025" "2"

-- is_localhost set for testing APIs --
-- Like: validate auth_token key
delete from "t_host_to_customer" where "custoemr_id" = '2';
insert into "t_host_to_customer" ( "customer_id", "host_name", "is_localhost" ) values
	  ( '2',  'http://192.168.0.200:9017', 'yes' )

	, ( '2',  'http://lonetree-ranch.beefchain.com', 'no' )

	, ( '2',  'http://192.154.97.75:9017', 'no' )
	, ( '2',  'http://192.154.97.75:9019', 'no' )
	, ( '2',  'http://192.154.97.75:9021', 'no' )
	, ( '2',  'http://192.154.97.75:9023', 'no' )
	, ( '2',  'http://192.154.97.75:9025', 'no' )
	, ( '2',  'http://192.154.97.75:9027', 'no' )
	, ( '2',  'http://192.154.97.75:9029', 'no' )

	, ( '2',  'http://2fa.agroledge.com:9017', 'no' )
	, ( '2',  'http://auth.agroledge.com:9019', 'no' )
	, ( '2',  'http://email.agroledge.com:9021', 'no' )
	, ( '2',  'http://livemon.agroledge.com:9023', 'no' )
	, ( '2',  'http://qrgen.agroledge.com:9025', 'no' )
;
