
select s_simulate_email( 'confirm_registration' , 'aaa', '1.1.1.1', 'http://localhost:9001', 'test', 'k' );

