
# Login

# Register

There are 2 forms of registration.  First is an e-mail confirmed registration.
This is what most sites use today.  You register and your account is not usable
until the email is confirmed.  There is also an immediate registration.  For
businesses where registration is handled by a representative of the business
this is a better way to handle registration.  It would be a mistake
to use both - except under unusual circumstances.  They have different
APIs and endpoints.  Configuration for a customer can turn on/off each of these
registration APIs.  In the configuration look for:

| Item                 | Value  | Description                                                                  |
|----------------------|--------|------------------------------------------------------------------------------|
| immediate.register   | yes    | if 'yes' then immediate registration is enabled and API can be called.       |
| email-conf.register  | yes    | if 'yes' then email-confirmed registration is enabled and API can be called. |




Email Confirmed
-----------------------------

POST to:
`
	/api/session/register_new_user
`

### Input Parameters

Can be GET or POST data parameters.

### Returns

### Configuration Options





Immediate Registration
-----------------------------

POST to:
`
	/api/session/register_immediate
`

### Input Parameters

Can be GET or POST data parameters.

| Param Name | Example Value | Description                                                       |
|------------|---------------|-------------------------------------------------------------------|
| username   | bob           | Username - can be email address.                                  |
| password   | uf72a!wv1f1z2 | Password                                                          |
| again      | uf72a!wv1f1z2 | Password 2nd copy - to verify agains "password"                   |
| email      | bob@abc.com   | email address for 'bob'                                           |
| real_name  | Bob Jones     | Persons name.                                                     |
| app        | myApp1        | per-customer application name for pulling up configuration data.  |

The Referrer URL is used to look up the per-customer data.


### Returns

On a successful registration:

```
{
    "status": "success",
    "auth_token": "c0ccbb21-d7fe-4a18-8a87-ff5f75846f9c",
    "config": "{}",
    "customer_id": "1",
    "jwt_token": "eyJhbGciOi...big-long-string...RKXLcaZQv6g6YqVk7Dw",
    "privs": "[]",
    "ranch_id": "89161c0a-4481-4605-89c7-4d41954936f7",
    "redir_to_app": "",
    "seq": "395c482a-63ad-48d8-8442-bf3845633ae8",
    "user_id": "cab33f96-3e68-4c68-874d-7df26cc4b04b",
    "xsrf_token": "7c5e5ce7-0bb5-4320-964e-a48fd026e39a"
}
```

On an error in registration:
```
{
	"status": "error",
	"msg": "reason for error"
}
```

### Configuration Options

1. use email as username
2. 



### NOTE

"p_url":"http://127.0.0.1:9019"
