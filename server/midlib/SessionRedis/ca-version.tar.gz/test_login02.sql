
select s_login('test01', '123456',  '1.1.1.1',  'http://www.2c-why.com/' );

