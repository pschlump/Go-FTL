
-- "Copyright (C) Philip Schlump, 2009-2017." 

-- Portions of this code are
-- "Copyright (C) American Certified Brands, 2018-2019" 

drop FUNCTION s_register_ranch(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_url varchar, p_app varchar );
drop FUNCTION s_register_ranch(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_ranch_name varchar, p_url varchar, p_app varchar );

drop FUNCTION s_register_ranch(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_ranch_name varchar, p_url varchar, p_app varchar, p_primary_phone varchar, p_address_ship varchar, p_address_usps varchar, p_note varchar );

CREATE or REPLACE FUNCTION s_register_ranch(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_ranch_name varchar, p_url varchar, p_app varchar, p_primary_phone varchar, p_address_ship varchar, p_address_usps varchar, p_note varchar )
	RETURNS varchar AS $$

DECLARE
    l_id 				varchar (40);
	l_email_token 		varchar (40);
	l_data				varchar (800);
	l_fail				bool;
	l_token				varchar (40);
	l_found				varchar (50);
	l_customer_id		varchar (40);
	l_bad_token			bool;
	l_from 				varchar (100);
	l_username_is_email varchar (10);
	l_have_email 		varchar (10);
	l_check_bad_pass	varchar (10);

    l_xsrf_token 		varchar (40);
    l_xsrf_mode 		varchar (100);

  	l_auth_token		varchar (40);
    l_seq 				varchar (40);
	l_ranch_id 			varchar (40);
    l_privs				varchar (400);
	l_config			varchar (7500);

	l_94_days 			varchar(50);
BEGIN

	-- "Copyright (C) American Certified Brands, 2018." 

	l_fail = false;
	l_data = '{"status":"success"}';

	l_customer_id = s_get_customer_id_from_url ( p_url );
	l_from = s_get_config_item( 'from.address', l_customer_id, 'pschlump@yahoo.com' );
	l_username_is_email = s_get_config_item( 'username.is.email', l_customer_id , 'no' );
	if l_username_is_email = 'yes' then
		p_username = p_email;
	end if;
	l_check_bad_pass = s_get_config_item( 'check.bad.password', l_customer_id, 'no' );

	l_id = uuid_generate_v4();
	l_email_token = uuid_generate_v4();

	begin
		select 'yes'
			into l_have_email
			from "t_user"
			where "email_address" = p_email
			;
	exception
		when no_data_found then
			l_have_email = 'no';
	end;
	if l_have_email = 'yes' then
		l_fail = true;
		l_data = '{"status":"error","msg":"Unable to create user with this username.  This email address is already in use.","code":"900"}';
	end if;

	if not l_fail then
		if l_check_bad_pass = 'yes' then

			select 'found'
				into l_found
				from t_common_pass
				where password = p_password
			;

			IF FOUND THEN
				l_fail = true;
				l_data = '{"status":"error", "code":"129", "msg":"Invalid password in list of most common passwords, pick a different one."}';
			END IF;

		end if;
	end if;

	if not l_fail then
		BEGIN
			insert into "t_user" ( "id", "username", "password", "ip", "real_name", "email_address"
					, "acct_state", "acct_expire", "email_confirmed" )
				values ( l_id, p_username, crypt(p_password,gen_salt('bf',8)), p_ip_addr, p_real_name, p_email
					, 'temporary', current_timestamp + interval '366 days', 'y' )
			;
		EXCEPTION WHEN unique_violation THEN
			l_fail = true;
			if l_username_is_email = 'yes' then
				l_data = '{"status":"error","msg":"Unable to create user with this email address.  Please choose a different email address.","code":"601"}';
			else
				l_data = '{"status":"error","msg":"Unable to create user with this username.  Please choose a different username (try your email address).","code":"602"}';
			end if;
		END;
	end if;

	-- merged code ----------------------------------------------------------------------------------------------------

	l_94_days = s_get_config_item( 'acct.auth_token.expire', l_customer_id, '94 days');

	-- ,	( '1', 'XSRF.token', 'per-user' )	-- or 'progressive-hashed' or 'off'
    l_xsrf_mode = s_get_xsrf_mode(l_customer_id);
	if l_xsrf_mode = 'per-user' or l_xsrf_mode = 'progressive-hashed' then
		l_xsrf_token = uuid_generate_v4();
	else
		l_xsrf_token = 'n/a';
	end if;

	/*
		CREATE TABLE "v1_ranch_name" (
			  "id"					char varying (40) DEFAULT uuid_generate_v4() not null primary key
			, "ranch_name"			text
			, "ranch_desc"			text
			, "ranch_location"		text
		);
	*/
	--					, "primary_phone"		: $("#primary_phone").val()		// new xyzzy102
	--					, "address_ship"		: $("#address_ship").val()
	--					, "address_usps"		: $("#address_usps").val()
	--					, "note"				: $("#note").val()

	if not l_fail then	
		BEGIN
			l_ranch_id = uuid_generate_v4();
			insert into "v1_ranch_name" (
				  "id"					
				, "ranch_name"		
				, "primary_phone"		
				, "address_ship"	
				, "address_usps"
				, "note"	
			) values (
				  l_ranch_id
				, p_ranch_name
				, p_primary_phone
				, p_address_ship	
				, p_address_usps
				, p_note	
			);
		EXCEPTION WHEN unique_violation THEN
			l_fail = true;
			l_data = '{"status":"error","msg":"Unable to create ranch.  Please choose a different ranch name.","code":"604"}';
		END;
	end if;

	if not l_fail then	
		l_auth_token = uuid_generate_v4();
		l_seq = uuid_generate_v4();
		insert into "t_auth_token" (
			  "auth_token"	
			, "user_id"	
			, "expire"
		) values (
			  l_auth_token
			, l_id
			, current_timestamp + l_94_days::interval
		);

		l_privs = '["ranch"]';
		l_config = '{}';

		-- insert into "t_output" ( "output" ) values ( 'Before success' );
		-- insert into "t_output" ( "output" ) values ( ' "ranch_id":'||to_json(l_ranch_id) );
		-- insert into "t_output" ( "output" ) values ( ' "auth_token":'||to_json(l_auth_token) );
		-- insert into "t_output" ( "output" ) values ( ' "seq":'||to_json(l_seq) );
		-- insert into "t_output" ( "output" ) values ( ' "privs":'||to_json(l_privs) );	
		-- insert into "t_output" ( "output" ) values ( ' "user_id":'||to_json(l_id) );
		-- insert into "t_output" ( "output" ) values ( ' "customer_id":'||to_json(l_customer_id) );
		-- insert into "t_output" ( "output" ) values ( ' "config":'||to_json(l_config) );
		-- insert into "t_output" ( "output" ) values ( ' "xsrf_token":'||to_json(l_xsrf_token) );

		l_data = '{"status":"success"'
			||', "ranch_id":'||to_json(l_ranch_id)
			||', "auth_token":'||to_json(l_auth_token)
			||', "seq":'||to_json(l_seq)
			||', "privs":'||to_json(l_privs)
			||', "user_id":'||to_json(l_id)
			||', "customer_id":'||to_json(l_customer_id)
			||', "config":'||to_json(l_config)
			||', "xsrf_token":'||to_json(l_xsrf_token)
			||', "$JWT-claims$":["auth_token"]'
			||', "$session$":{'
					||'"set":['
						||'{"path":["user","$is_logged_in$"],"value":"y"}'
						||',{"path":["user","$xsrf_token$"],"value":'||to_json(l_xsrf_token)||'}'
					||']'
				||'}'
			||'}';

		-- insert into "t_output" ( "output" ) values ( 'After success' );

	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;








drop FUNCTION s_test_cleanup_user(p_username varchar,  p_email varchar, p_test_auth_token varchar );

CREATE or REPLACE FUNCTION s_test_cleanup_user(p_username varchar,  p_email varchar, p_test_auth_token varchar )
	RETURNS varchar AS $$

DECLARE
    l_id 				varchar (40);
	l_data				varchar (80);
BEGIN
	l_data = '{"status":"success"}';

	if p_test_auth_token = '6861c2d2-4248-4001-5289-71b6242a59af' then
		delete from "t_auth_token" where "user_id" in ( select "id" from "t_user" where "username" = p_username );
		delete from "t_user" where "username" = p_username;
		delete from "t_auth_token" where "user_id" in ( select "id" from "t_user" where "email_address" = p_email );
		delete from "t_user" where "email_address" = p_email;
	else
		l_data = '{"status":"error","msg":"invalid test auth token"}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;

-- Test: select s_test_cleanup_user ( 'pschlump@gmail.com', 'pschlump@gmail.com', '6861c2d2-4248-4001-5289-71b6242a59af');
-- URL http://127.0.0.1:9019/api/session/test_cleanup_user&username=pschlump@gmail.com&email=pschlump@gmail.com?test_auth_token=6861c2d2-4248-4001-5289-71b6242a59af&_ran_=123
