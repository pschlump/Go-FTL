
select s_login('test01', 'yanky444',  '1.1.1.1',  'http://www.2c-why.com/' );

