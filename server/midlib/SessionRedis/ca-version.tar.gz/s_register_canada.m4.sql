
--
-- Description: Register a user - not using email registration for confirmation.
--

-- "Copyright (C) Philip Schlump, 2009-2017." 

-- 
-- Sample Success Output:
--
-- Before post-process:
--
-- {
--     "$JWT-claims$": [
--         "auth_token"
--     ],
--     "auth_token": "edac8cdc-c06c-4a2e-b370-df72d3dccf11",
--     "config": "{}",
--     "customer_id": "error-missing-url-to-customer",
--     "privs": "[]",
--     "ranch_id": "d7a7ff7c-5cb3-49f1-b586-d98b9a7d1aa8",
--     "redir_to_app": "",
--     "seq": "932e08e4-54c1-48a8-a60f-7b4e840dfadb",
--     "status": "success",
--     "user_id": "a7cdcac3-4530-4a03-8a38-1340151a916f",
--     "xsrf_token": "n/a"
-- }
--
-- As sent to Browser/Client
--
-- {
--     "auth_token": "c0ccbb21-d7fe-4a18-8a87-ff5f75846f9c",
--     "config": "{}",
--     "customer_id": "error-missing-url-to-customer",
--     "jwt_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdXRoX3Rva2VuIjoiYzBjY2JiMjEtZDdmZS00YTE4LThhODctZmY1Zjc1ODQ2ZjljIn0.KkuOLHlL475p16qA_xRBlMJE6zgnoAzQpSH2AEuVnGCDa4mdQzckbp59uWemhYisjwPjcded-bvQSVb6GmN7vj_F0qKZSYXCiIMealnnCGXSXzlKKNGXnFCPEh_uB_axM-oFxlULpxVfAXZyoK-0kaIrOp-8Kh-yqBImlGElfyp-3v-k75nHQVgS2f8u2_8z9fO0AVQZc_HjIkKtPy_h5foBG5HSQFhvCTrNiv4zwZOwlfEqZjgTTrzUf_04wG5wVWIJsYEeiCmaXWA-38MZCpePrTnk30e7aUVWzgXFndruDoUckr5_4vlEFYn4ZOXch8gRKXLcaZQv6g6YqVk7Dw",
--     "privs": "[]",
--     "ranch_id": "89161c0a-4481-4605-89c7-4d41954936f7",
--     "redir_to_app": "",
--     "seq": "395c482a-63ad-48d8-8442-bf3845633ae8",
--     "status": "success",
--     "user_id": "cab33f96-3e68-4c68-874d-7df26cc4b04b",
--     "xsrf_token": "n/a"
-- }
--
-- Errors are all with "msg" and "status" != "success"
--

--
-- xyzzy
-- CREATE TABLE "t_email_q" (
-- 	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
-- 	, "seq"					bigint DEFAULT nextval('t_email_id_seq'::regclass) NOT NULL 
-- 	, "status"				char varying (30) DEFAULT 'pending' not null
-- 	, "error_msg"			text	-- if status == 'error' then message/data on error
-- 	, "input_data"			text	-- JSON data to use with template to generate email/body
-- 	, "template_file_name"	text	-- input - file name of the template file
-- );	
-- 

drop FUNCTION s_register_canada(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_ranch_name varchar, p_url varchar, p_app varchar, p_method varchar );
drop FUNCTION s_register_immediate(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_ranch_name varchar, p_url varchar, p_app varchar, p_method varchar );

CREATE or REPLACE FUNCTION s_register_immediate(p_username varchar, p_password varchar, p_again varchar, p_ip_addr varchar, p_email varchar, p_real_name varchar, p_ranch_name varchar, p_url varchar, p_app varchar, p_method varchar )
	RETURNS varchar AS $$

DECLARE
    l_id 				varchar (40);
	l_email_token 		varchar (40);
	l_data				varchar (1200);
	l_fail				bool;
	l_new_user_created  bool;
	l_token				varchar (40);
	l_found				varchar (50);
	l_customer_id		varchar (40);
	l_bad_token			bool;
	l_from 				varchar (100);
	l_username_is_email varchar (10);
	l_have_email 		varchar (10);
	l_check_bad_pass	varchar (10);

    l_xsrf_token 		varchar (40);
    l_xsrf_mode 		varchar (100);

  	l_auth_token		varchar (40);
    l_seq 				varchar (40);
	l_ranch_id 			varchar (40);
    l_privs				varchar (400);
	l_config			varchar (7500);

	l_94_days 			varchar(50);
	l_acct_state 		varchar(50);
	l_use_2fa 			varchar(50);

	-- New --
	l_redirect_to		varchar (400);
	l_redirect_to_app	varchar (400);
	l_debug_on			bool;

	-- New New email related --
	l_reg_URL_2fa_setup		varchar(80);
	l_reg_URL_2fa_app		varchar(80);
	l_2fa_unique_id 		varchar(40);

	l_reg_URL_qr_base		varchar(80);
	l_reg_template_name		varchar(80);
	l_reg_URL_kick 			varchar(80);

	l_qr_data 				qr_type;
	l_hash					varchar(20);

BEGIN

	-- "Copyright (C) Philip Schlump, 2009-2019." 

	l_debug_on = s_debug_flag_enabled( 's_register_immediate' );

	if l_debug_on then
		insert into "t_output" ( "output" ) values ( ' "p_url":'||to_json(p_url) );
	end if;

	l_fail = false;
	l_data = '{"status":"success"}';

	if p_app is null or p_app = '' then
		p_app = 'test-app';
	end if;

	if s_ip_ban(p_ip_addr) then
		l_data = '{ "status":"error", "code":"8201", "msg":"Invalid username or password." }';
		l_fail = true;
	end if;

	l_customer_id = s_get_customer_id_from_url ( p_url );

	-- -------------------------------------------------------------------------------------------------------------------------------

	-- | immediate.register   | yes    | if 'yes' then immediate registration is enabled and API can be called.       |
	-- | email-conf.register  | yes    | if 'yes' then email-confirmed registration is enabled and API can be called. |
	l_found = s_get_config_item( 'immediate.register', l_customer_id , 'yes' );
	if l_found <> 'yes' then
		l_data = '{ "status":"error", "code":"8201", "msg":"API is not configured.  See: immediate.register configuration item." }';
		l_fail = true;
	end if;

	-- ,	( '1', '2fa.required', 'no' )		-- yes/no - if yes then login is not finished unilt 2fa "pin" is provided.
	l_use_2fa = s_get_config_item( '2fa.required', l_customer_id , 'yes' );

	l_from = s_get_config_item( 'from.address', l_customer_id, 'pschlump@gmail.com' );
	l_username_is_email = s_get_config_item( 'username.is.email', l_customer_id , 'no' );
	if l_username_is_email = 'yes' then
		p_username = p_email;
	end if;


	-- ----------------------------------------------------------------------------------------------------
	-- Check to see if email/username is already usd.
	-- ----------------------------------------------------------------------------------------------------
	if not l_fail then
		begin
			select 'yes'
				into l_have_email
				from "t_user"
				where "email_address" = p_email
				;
		exception
			when no_data_found then
				l_have_email = 'no';
		end;
		if l_have_email = 'yes' then
			l_fail = true;
			l_data = '{"status":"error","msg":"Unable to create user with this username.  This email address is already in use.","code":"8000"}';
		end if;
	end if;

	-- ----------------------------------------------------------------------------------------------------
	-- Check for really bad passwords.
	-- ----------------------------------------------------------------------------------------------------
	l_check_bad_pass = s_get_config_item( 'check.bad.password', l_customer_id, 'no' );
	if not l_fail then
		if l_check_bad_pass = 'yes' then

			select 'found'
				into l_found
				from t_common_pass
				where password = p_password
			;

			IF FOUND THEN
				l_fail = true;
				l_data = '{"status":"error", "code":"8129", "msg":"Invalid password in list of most common passwords, pick a different one."}';
			END IF;

		end if;
	end if;

	l_id = uuid_generate_v4();
	l_email_token = uuid_generate_v4();

	-- merged code ----------------------------------------------------------------------------------------------------

	l_94_days = s_get_config_item( 'acct.auth_token.expire', l_customer_id, '94 days');

	-- ,	( '1', 'XSRF.token', 'per-user' )	-- or 'progressive-hashed' or 'off'
    l_xsrf_mode = s_get_xsrf_mode(l_customer_id);
	if l_xsrf_mode = 'per-user' or l_xsrf_mode = 'progressive-hashed' then
		l_xsrf_token = uuid_generate_v4();
	else
		l_xsrf_token = 'n/a';
	end if;

	/*
		CREATE TABLE "v1_ranch_name" (
			  "id"					char varying (40) DEFAULT uuid_generate_v4() not null primary key
			, "ranch_name"			text
			, "ranch_desc"			text
			, "ranch_location"		text
		);
	*/

	if not l_fail then	
		BEGIN
			l_ranch_id = uuid_generate_v4();
			insert into "v1_ranch_name" (
				  "id"					
				, "ranch_name"		
				, "user_id"
			) values (
				  l_ranch_id
				, p_ranch_name
				, l_id
			);
		EXCEPTION WHEN unique_violation THEN
			l_fail = true;
			l_data = '{"status":"error","msg":"Unable to create ranch.  Please choose a different ranch name.","code":"8604"}';
		END;
	end if;

	if not l_fail then	
		-- xyzzy - pull out to own function s_get_redirect_to
		select "value"
			into l_redirect_to
			from "t_config"
			where "item_name" = 'register.redirect.to'
			  and "customer_id" = l_customer_id
			;
			l_redirect_to = p_url || l_redirect_to;
		if not found then
			l_redirect_to = p_url || '/';
		end if;

		select "value"
			into l_redirect_to_app
			from "t_config"
			where "item_name" = 'register.redirect.to.app'
			  and "customer_id" = l_customer_id
			;
		if not found then
			l_redirect_to_app = '';
		end if;
	end if;

	------------------------------------------------------------------------------------------------------
	-- Commit Point - create user now 																	--
	------------------------------------------------------------------------------------------------------

	l_acct_state = 'temporary';
	if l_use_2fa = 'yes' then
		l_acct_state = '2fa-pend';
		if l_debug_on then
			insert into "t_output" ( "output" ) values ( '2fa is required' );
		end if;
	end if;
	
	if not l_fail then
		l_new_user_created = false;
		l_2fa_unique_id = uuid_generate_v4();
		BEGIN
			insert into "t_user" (
					  "id"
					, "username"
					, "password"
					, "ip"
					, "real_name"
					, "email_address"
					, "acct_state"
					, "acct_expire"
					, "email_confirmed"
					, "email_reset_key"
					, "x2fa_id"				
				) values (
					  l_id
					, p_username
					, crypt(p_password,gen_salt('bf',8))
					, p_ip_addr
					, p_real_name
					, p_email
					, l_acct_state
					, current_timestamp + interval '366 days'
					, 'n'		
					, l_email_token
					, l_2fa_unique_id
				);
			l_new_user_created = true;
		EXCEPTION WHEN unique_violation THEN
			l_fail = true;
			if l_username_is_email = 'yes' then
				l_data = '{"status":"error","msg":"Unable to create user with this email address.  Please choose a different email address.","code":"8601"}';
			else
				l_data = '{"status":"error","msg":"Unable to create user with this username.  Please choose a different username (try your email address).","code":"8602"}';
			end if;
		END;
	end if;

	-- xyzzy- could be simplified!!!
	if not l_fail then	
		select 
				  "t_user"."privs"
				, "t_customer"."config"
			into 
				  l_privs 	
				, l_config
			from "t_user" as "t_user" left join "t_customer" as "t_customer" on "t_customer"."id" = "t_user"."customer_id"
			where "t_user"."id" = l_id
			;
		if not found then
			l_privs = '["ranch"]';
			l_config = '{}';
			-- l_fail = true;
			-- l_data = '{"status":"error","msg":"Invalid Token or Expired Token","code":"8202","email_auth_token":'||to_json(p_email_auth_token)||'}';
		end if;
	end if;

	if l_fail and l_new_user_created then
		delete from "t_suer" where "id" = l_id;
	end if;

	if not l_fail then	
		l_auth_token = uuid_generate_v4();
		l_seq = uuid_generate_v4();
		insert into "t_auth_token" (
			  "auth_token"	
			, "user_id"	
			, "expire"
		) values (
			  l_auth_token
			, l_id
			, current_timestamp + l_94_days::interval
		);

		if l_config is null or l_config = '' then
			l_config = '{}';
		end if;

		if l_debug_on then
			insert into "t_output" ( "output" ) values ( 'Before success' );
			insert into "t_output" ( "output" ) values ( ' "ranch_id":'||to_json(l_ranch_id) );
			insert into "t_output" ( "output" ) values ( ' "auth_token":'||to_json(l_auth_token) );
			insert into "t_output" ( "output" ) values ( ' "seq":'||to_json(l_seq) );
			insert into "t_output" ( "output" ) values ( ' "l_email_token":'||to_json(l_email_token) );
			insert into "t_output" ( "output" ) values ( ' "privs":'||to_json(l_privs) );	
			insert into "t_output" ( "output" ) values ( ' "user_id":'||to_json(l_id) );
			insert into "t_output" ( "output" ) values ( ' "customer_id":'||to_json(l_customer_id) );
			insert into "t_output" ( "output" ) values ( ' "config":'||to_json(l_config) );
			insert into "t_output" ( "output" ) values ( ' "xsrf_token":'||to_json(l_xsrf_token) );
			insert into "t_output" ( "output" ) values ( ' "l_redirect_to":'||to_json(l_redirect_to) );
			insert into "t_output" ( "output" ) values ( ' "l_use_2fa":'||to_json(l_use_2fa) );
		end if;

		if l_debug_on then
			insert into "t_output" ( "output" ) values ( ' "l_redirect_to_app":'||to_json(l_redirect_to_app) );
		end if;


-- xyzzy insert into t_email_q
-- send back - t_email_q ID
-- send back - KICK URL
-- use - URL for Email Template
-- use - URL for 2fa setup Template
-- use - URL for QR Code to setup 2fa
--		 	( '1', 'register.email_template', 'register_email.tmpl' )
--		,	( p_customer_id, 'register.PATH_template', './tmpl' )
--		,	( p_customer_id, 'register.URL_2fa_setup', 'http://auth.simple-auth.com/2fasetup' )
--		,	( p_customer_id, 'register.URL_qr_base', 'http://auth.simple-auth.com/qr/' )
--		,	( p_customer_id, 'register.PATH_qr_base', './qr' )
--		,	( p_customer_id, 'register.URL_2fa_app', 'http://2fa.simple-auth.com/' )
--		,	( '2', 'register.PATH_template', './tmpl/app.beefchain.com' )
--		,	( '2', 'register.URL_2fa_setup', 'http://auth.agroledge.com/2fasetup' )
--		,	( '2', 'register.URL_qr_base', 'http://auth.agroledge.com/qr/' )
--		,	( '2', 'register.PATH_qr_base', './qr' )
--		,	( '2', 'register.URL_2fa_app', 'http://2fa.agroledge.com/' )
--		,	( '2', 'register.email_template', 'register_email.tmpl' )
	-- set value = 'http://127.0.0.1:9019/setup-2fa.html?qr={{.URL_qr_base}}{{.QRImgURL}}&x2fa_id={{.x2fa_unique_id}}&otk_list={{.otk_list}}&qr_id={{.qr_id}}&qr_enc_id={{.qr_enc_id}}'

		l_reg_URL_2fa_setup = s_get_config_item( 'register.URL_2fa_setup', l_customer_id, 'http://2fa.simple-auth.com/msetup.html' );	-- http://127.0.0.1:9021/msetup.html?id={{.hash}}
		l_reg_URL_qr_base = s_get_config_item( 'register.URL_qr_base', l_customer_id, 'http://auth.simple-auth.com/' );					-- http://127.0.0.1:9019
		l_reg_URL_2fa_app = s_get_config_item( 'register.URL_2fa_app', l_customer_id, 'http://2fa.simple-auth.com/' );					-- http://127.0.0.1:9021
		l_reg_template_name = s_get_config_item( 'register.email_template', l_customer_id, './tmpl/register_email.tmpl' );
		if p_ranch_name = '1d217e902Bc1deB2e75D1Ec44bcAE03A1227a126' then
			l_reg_template_name = './tmpl/test_confirm_registration.tmpl' 
		end if;
		l_reg_URL_kick = s_get_config_item( 'register.URL_kick', l_customer_id, 'http://email.simple-auth.com/kick' );					-- http://127.0.0.1:9022/kick

		-- get QR code, URL, Path := s_get_qr_code ( 'with-out-icon' )
			-- Get ID for QR code	
			-- CREATE TABLE "t_avail_qr" (
			-- CREATE or REPLACE FUNCTION s_get_qr_json(p_type varchar)
			-- CREATE or REPLACE FUNCTION s_get_qr(p_type varchar)
		l_qr_data = s_get_qr('non-branded');

-- Get the one-time codes to return
--		l_one_time_coes = s_get_one_time_codes(l_customer_id,l_id);

-- DO the post-process to setup the QR Redirect to the setup-path (use 2fa_unique_id) in redirect -- DoGet(...)
-- DO Add in the 1-time keys - PDF or list?
	-- Q's - get list of 1 time codes for this user?
	--	, "CallAfter": ["CreateJWTToken", "SetupQRCodeRedirect", "KickEmail", "RedirectTo", "X2faSetup"]

		select random_string(16) into l_hash;

		perform s_setup_2fa_tables(l_2fa_unique_id, l_id, l_hash, l_qr_data.qr_id);

--		html, QRImgURL, ID, qr_ttl, err := GetQRForSetup(hdlr, www, req, ps, ed.UserID)
--		_ = html
--		_ = qr_ttl
-- stmt := "select \"qr_enc_id\", \"url_path\" from \"t_avail_qr\" where \"state\" = 'avail' limit 1"

		insert into "t_email_q" (
			  "input_data"		
			, "user_id"
			, "template_file_name"	
		) values (
			  '{'
				||'  "user_id":'||to_json(s_nvl(l_id))
				||', "subject":"Confirm Registration"'
				||', "to":'||to_json(p_email)
				||', "from":'||to_json(l_from)
				||', "url":'||to_json(p_url)
				||', "email_token":'||to_json(s_nvl(l_email_token))
				||', "real_name":'||to_json(s_nvl(p_real_name))
				||', "ranch_name":'||to_json(s_nvl(p_ranch_name))
				||', "ranch_id":'||to_json(l_ranch_id)
				||', "customer_id":'||to_json(l_customer_id)
				||', "use_2fa":'||to_json(l_use_2fa)
				||', "hash":'||to_json(l_hash)
				||', "x2fa_unique_id":'||to_json(l_2fa_unique_id)
				||', "URL_2fa_setup":'||to_json(l_reg_URL_2fa_setup)
				||', "URL_qr_base":'||to_json(l_reg_URL_qr_base)
				||', "URL_2fa_app":'||to_json(l_reg_URL_2fa_app)
				||', "QRImgURL":'||to_json(l_qr_data.url_path)
				||', "X2fa_Temp_ID":'||to_json(l_2fa_unique_id)
				||', "qr_id":'||to_json(l_qr_data.qr_id)
				||', "qr_enc_id":'||to_json(l_qr_data.qr_enc_id)
				||'}'
			, l_id
			, l_reg_template_name
		);


		l_data = '{"status":"success"'
			||', "ranch_id":'||to_json(l_ranch_id)
			||', "auth_token":'||to_json(l_auth_token)
			||', "email_token":'||to_json(s_nvl(l_email_token))
			||', "URL_kick":'||to_json(l_reg_URL_kick)
			||', "privs":'||to_json(l_privs)
			||', "user_id":'||to_json(l_id)
			||', "customer_id":'||to_json(l_customer_id)
			||', "config":'||to_json(l_config)
			||', "xsrf_token":'||to_json(l_xsrf_token)
			||', "$JWT-claims$":["auth_token"]'
			||', "redir_to_app":'||to_json(l_redirect_to_app)
			||', "use_2fa":'||to_json(l_use_2fa)					-- 2fa Post Process - Setup2FA Post Process
			||', "2fa_unique_id":'||to_json(l_2fa_unique_id)		-- 2fa Post Process - Setup2FA Post Process
			||', "URL_2fa_setup":'||to_json(l_reg_URL_2fa_setup)	-- 2fa Post Process - Setup2FA Post Process
				||', "QRImgURL":'||to_json(l_qr_data.url_path)
				||', "qr_id":'||to_json(l_qr_data.qr_id)
				||', "qr_enc_id":'||to_json(l_qr_data.qr_enc_id)
			||', "hash":'||to_json(l_hash)							-- 2fa stuff
			||', "fail_recover":"s_cleanup_failed_register"'
			||', "$session$":{'
					||'"set":['
						||'{"path":["user","$is_logged_in$"],"value":"y"}'
						||',{"path":["user","$xsrf_token$"],"value":'||to_json(l_xsrf_token)||'}'
					||']'
				||'}'
			||'}';

		if l_debug_on then
			insert into "t_output" ( "output" ) values ( 'After success' );
		end if;
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;








drop FUNCTION s_cleanup_failed_register(p_username varchar, p_user_id varchar, p_ranch_id varchar);

CREATE or REPLACE FUNCTION s_cleanup_failed_register(p_username varchar, p_user_id varchar, p_ranch_id varchar)
	RETURNS varchar AS $$
DECLARE
	l_data				varchar (40);
	l_debug_on			bool;
BEGIN

	-- "Copyright (C) Philip Schlump, 2009-2019." 

	l_data = '{"status":"success"}';
	l_debug_on = s_debug_flag_enabled( 's_register_immediate' );

	delete from "v1_ranch_name"
		where "user_id" in (
			select "id" from "t_user"
				where "id" = p_user_id
				  and "username" = p_username
				  and "email_confirmed" = 'n'
		);
		
	delete from "t_auth_token"
		where "user_id" in (
			select "id" from "t_user"
				where "id" = p_user_id
				  and "username" = p_username
				  and "email_confirmed" = 'n'
		);

	update "t_email_q"
		set "status" = 'failed'
		where "user_id" in (
			select "id" from "t_user"
				where "id" = p_user_id
				  and "username" = p_username
				  and "email_confirmed" = 'n'
		);
	
	delete from "t_user"
		where "id" = p_user_id
		  and "username" = p_username
		  and "email_confirmed" = 'n'
		;

	if l_debug_on then
		insert into "t_output" ( "output" ) values ( ' "cleanup of failed register":'||to_json(p_user_id)||' user_id='||to_json(p_username) );
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;


