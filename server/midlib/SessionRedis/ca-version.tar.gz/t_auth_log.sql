





-- "Copyright (C) Philip Schlump, 2019." 






CREATE TABLE "t_auth_log" (
	  "id"					char varying(40) DEFAULT uuid_generate_v4() not null primary key
  	, "user_id" 			char varying (40) not null			 						
	, "outcome"				text not null
	, "updated" 			timestamp 									 						
	, "created" 			timestamp default current_timestamp not null 					
);



CREATE OR REPLACE function t_auth_log_upd()
RETURNS trigger AS 
$BODY$
BEGIN
  NEW.updated := current_timestamp;
  RETURN NEW;
END
$BODY$
LANGUAGE 'plpgsql';


CREATE TRIGGER t_auth_log_trig
BEFORE update ON "t_auth_log"
FOR EACH ROW
EXECUTE PROCEDURE t_auth_log_upd();



