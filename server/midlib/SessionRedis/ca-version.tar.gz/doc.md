Login and Account Maintenance 
=============================

1. Registration flow

	1. Register : Creates an account and sends a confirmation email.

		Email: sent to user ...

	2. Confirm: Via Link

		Redirects to:  Logged in state.

	3. Confirm: Via Cut/Paste of Token

		Redirects to:  Logged in state.

	4. Request recovery of password:

		Email: sent to user ...

	5. Password Recovery: Via Link

		Redirects to:  Logged in state.

	6. Password Recovery: Via Cut/Paste of Token

		Redirects to:  Logged in state.

	7. Change Password

		Email: sent to user to tell them that the password was changed.

	8. Change Account Information

	9. Logout



