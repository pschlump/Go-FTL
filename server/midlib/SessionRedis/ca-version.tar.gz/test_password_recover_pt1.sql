
select s_password_reset ( 'test01', null, null, '1.1.1.1', 'http://auth.2c-why.com' );

