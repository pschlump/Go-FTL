select 'EMAIL_'||'RESET_KEY', "email_reset_key"
from "t_user"
where "username" = 'test01'
;
