





delete from "t_user";
delete from "t_auth_token";

