





-- "Copyright (C) Philip Schlump, 2016."








CREATE TYPE qr_type AS (
	id					varchar (40),
	file_name			varchar (100),
	url_path			varchar (100),
	file_name_nbr		varchar (100),
	url_path_nbr		varchar (100),
	qr_id				varchar (20),
	qr_enc_id			varchar (20)
);
