
-- "Copyright (C) Philip Schlump, 2009-2017." 

m4_include(types.m4)

drop table "t_ip_ban" ;

CREATE TABLE "t_ip_ban" (
	  "ip"					char varying(50) not null primary key
	, "created" 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

insert into "t_ip_ban" ( "ip" ) values ( '1.1.1.2' );	-- normally the first 20 chars of the SHA hash of the ip is what is stored.

