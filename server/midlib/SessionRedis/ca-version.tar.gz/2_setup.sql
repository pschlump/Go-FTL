
	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '1', 'register.PATH_template', './tmpl' )
		,	( '1', 'register.URL_2fa_setup', 'http://auth.simple-auth.com/2fasetup' )
		,	( '1', 'register.URL_qr_base', 'http://auth.simple-auth.com/qr/' )
		,	( '1', 'register.PATH_qr_base', './qr' )
		,	( '1', 'register.URL_2fa_app', 'http://2fa.simple-auth.com/' )

		,	( '2', 'register.PATH_template', './tmpl/app.beefchain.com' )
		,	( '2', 'register.URL_2fa_setup', 'http://auth.agroledge.com/2fasetup' )
		,	( '2', 'register.URL_qr_base', 'http://auth.agroledge.com/qr/' )
		,	( '2', 'register.PATH_qr_base', './qr' )
		,	( '2', 'register.URL_2fa_app', 'http://2fa.agroledge.com/' )
;
	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '1', 'register.email_template', 'register_email.tmpl' )
		,	( '2', 'register.email_template', 'register_email.tmpl' )
;


--	l_from = s_get_config_item( 'from.address', l_customer_id, 'pschlump@gmail.com' );

	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '1', 'from.address', 'pschlump@gmail.com' )
;
	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '2', 'from.address', 'pschlump@gmail.com' )
;

--	l_username_is_email = s_get_config_item( 'username.is.email', l_customer_id , 'no' );

	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '2', 'username.is.email', 'yes' );
;

--		l_reg_URL_kick = s_get_config_item( 'register.URL_kick', l_customer_id, 'http://email.simple-auth.com/kick' );
	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '1', 'register.URL_kick', 'http://email.simple-auth.com/kick' );
;
	insert into "t_config" ( "customer_id", "item_name", "value" ) values
		 	( '2', 'register.URL_kick', 'http://email.agroledge.com/kick' );
;

update "t_config"
	set "value" = 'http://127.0.0.1:9019/qr/' 
	where "customer_id" = '2' 
	  and "item_name" = 'register.URL_qr_base'
;

-- l_reg_URL_qr_base = s_get_config_item( 'register.URL_qr_base', l_customer_id, 'http://auth.simple-auth.com/' );					-- http://127.0.0.1:9019
update "t_config"
	set "value" = 'http://127.0.0.1:9019/' 
	where "customer_id" = '1' 
	  and "item_name" = 'register.URL_qr_base'
;

-- OLD: update t_config set value = 'http://127.0.0.1:9019/setup-2fa.html?qr={{.URL_qr_base}}{{.QRImgUrl}}&x2fa_id={{.x2fa_unique_id}}&otk_list={{.otk_list}}&qr_id={{.qr_id}}&qr_enc_id={{.qr_enc_id}}' where item_name = 'register.redirect.to';
update t_config set value = 'http://127.0.0.1:9019/setup-2fa.html?qr={{.QRImgURL}}&x2fa_id={{.x2fa_unique_id}}&otk_list={{.otk_list}}&qr_id={{.qr_id}}&qr_enc_id={{.qr_enc_id}}' where item_name = 'register.redirect.to';
