
-- "Copyright (C) Philip Schlump, 2009-2017." 

m4_include(types.m4)

drop TABLE "t_customer" ;

CREATE TABLE "t_customer" (
	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
	, "name"				m4_uuid_type() not null
	, "ctype"				char varying (10) check ( "ctype" in ( 'regular', 'admin', 'test' ) ) default 'test' not null
	, "config"				text default '{}' not null
);

