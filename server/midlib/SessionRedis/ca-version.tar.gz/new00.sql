CREATE or REPLACE FUNCTION s_get_qr_data(p_user_id varchar, p_x2fa_unique_id varchar)
	RETURNS qr_type AS $$
DECLARE
	result_record qr_type;
	l_debug_on			bool;
BEGIN

	-- "Copyright (C) Philip Schlump, 2017." 

	l_debug_on = s_debug_flag_enabled( 's_get_qr_json' );

	select 
			  "id"
			, "file_name"			
			, "url_path"		
			, "file_name_nbr"
			, "url_path_nbr"		
			, "qr_id"			
			, "qr_enc_id"	
		into
			  result_record.id
			, result_record.file_name			
			, result_record.url_path		
			, result_record.file_name_nbr
			, result_record.url_path_nbr
			, result_record.qr_id	
			, result_record.qr_enc_id			
		from "t_avail_qr"
		where "qr_id" = ( 
			select "qr_id"
			from "t_2fa"
			where "id" = p_x2fa_unique_id
			  and "user_id" = p_user_id
			)
		limit 1
		;

	-- if l_debug_on then
	-- 	insert into "t_output" ( "output" ) values ( ' "cleanup of failed register":'||to_json(p_user_id)||' user_id='||to_json(p_username) );
	-- end if;

	RETURN result_record;
END;
$$ LANGUAGE plpgsql;


