sessionRedis.go:			if hdlr.gCfg.DbOn("*", "SessionRedis", "db1") {
sessionRedis.go:			if hdlr.gCfg.DbOn("*", "SessionRedis", "db1") {
sessionRedis.go:				if hdlr.gCfg.DbOn("*", "SessionRedis", "db1") {
sessionRedis.go:	if hdlr.gCfg.DbOn("*", "SessionRedis", "db1") {
