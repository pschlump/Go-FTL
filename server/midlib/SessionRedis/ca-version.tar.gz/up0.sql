
-- Remember to set vorig: in Redis also
-- Remember to run go-ftl and agroledg.linux

alter table "v1_ranch_name" add column "user_id"		char varying (40) ;

\i s_ran_str.m4.sql
\i ../../../tools/qr-micro-service/v1_avail_qr.sql
\i s_register_canada.sql

