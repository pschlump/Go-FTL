
select s_validate_token( 'bobob4', 'c850b500-6555-492c-aa60-483ff352aa48' );

