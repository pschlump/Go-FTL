






-- "Copyright (C) Philip Schlump, 2009-2017." 

CREATE SEQUENCE t_email_test_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1000
  CACHE 1;

