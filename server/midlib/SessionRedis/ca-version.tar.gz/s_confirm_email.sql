




--
-- Description: Confirm a user from an email link.  This is in response to a "GET" request. 
--
-- The form/"POST" request is different.  "POST" skips the redirect because it is from a form in the applicaiton.
--
-- Questions:
-- 0. Perform login at this point in time?
-- 0. Is this different than confirm a user from a token cut/paste into app? -- Should the "app" just do a "POST" to this? v.s. a "GET" when link?
--		Should "$method$" be bassed to this? -- GET is link, POST is form.
-- 1. Do we need to store the xsrf_token in cookie/local-storage - so it will persis across browser restar/bad-network?
-- 1. If we redirect - how to pas xsrf_token back to redirected location (URL?/Cookie?)
-- 2. If we need to pass the "auth_token" and CORS how?
-- 3. $log_it_error$ -- post processing - send message to log 
-- 3. $log_it_info$ -- post processing - send message to log 
-- 3. $log_it_warn$ -- post processing - send message to log
--
-- "Copyright (C) Philip Schlump, 2009-2019." 
--

drop FUNCTION s_confirm_email ( p_email_auth_token varchar, p_ip_addr varchar, p_url varchar, p_method varchar );

CREATE or REPLACE FUNCTION s_confirm_email ( p_email_auth_token varchar, p_ip_addr varchar, p_url varchar, p_method varchar )
	RETURNS varchar AS $$
DECLARE
	l_data				varchar(1800);
	l_customer_id		varchar(40);
	l_junk				varchar(40);
	l_fail 				boolean;
	l_redirect_to		varchar (400);
	l_redirect_to_app	varchar (400);
    l_xsrf_token 		varchar (40);
    l_xsrf_mode 		varchar (100);

  	l_auth_token		varchar (40);
    l_seq 				varchar (40);
    l_id 				varchar (40);
    l_privs				varchar (400);
	l_config			varchar (7500);

	l_redir 			varchar (400);
	l_94_days 			varchar(50);
	l_use_2fa 			varchar(50);
	l_2fa_unique_id 	varchar(40);
	l_otk_list			varchar(400);

	l_debug_on			bool;
	l_qr_data 			qr_type;
	l_reg_URL_qr_base	varchar(80);
BEGIN

	-- "Copyright (C) Philip Schlump, 2009-2017." 

	l_fail = false;
	l_data = '{"status":"success"}';
	l_debug_on = s_debug_flag_enabled( 's_confirm_email' );

	if p_email_auth_token is null or p_email_auth_token = '' then
		l_data = '{ "status":"error", "code":"200", "msg":"Invalid p_email_auth_token." }';
		l_fail = true;
	end if;

	if s_ip_ban(p_ip_addr) then
		l_data = '{ "status":"error", "code":"201", "msg":"Invalid username or password." }';
		l_fail = true;
	end if;

	l_customer_id = s_get_customer_id_from_url ( p_url );
	l_use_2fa = s_get_config_item( '2fa.required', l_customer_id , 'yes' );

	-- xyzzy - pull out to own function s_get_redirect_to
	select "value"
		into l_redirect_to
		from "t_config"
		where "item_name" = 'register.redirect.to'
		  and "customer_id" = l_customer_id
		;
	if not found then
		l_redirect_to = p_url || '/';
	end if;

	select "value"
		into l_redirect_to_app
		from "t_config"
		where "item_name" = 'register.redirect.to.app'
		  and "customer_id" = l_customer_id
		;
	if not found then
		l_redirect_to_app = '';
	end if;


	if not l_fail then	
		select "t_user"."id"
			, "t_user"."privs"
			, "t_user"."customer_id"
			, "t_user"."x2fa_id"				
			, "t_customer"."config"
			into l_id
			, l_privs 	
			, l_customer_id 	
			, l_2fa_unique_id 
			, l_config
			from "t_user" as "t_user" left join "t_customer" as "t_customer" on "t_customer"."id" = "t_user"."customer_id"
			where "email_reset_key" = p_email_auth_token
			;
		if not found then
			l_fail = true;
			l_data = '{"status":"error","msg":"Invalid Token or Expired Token","code":"202","email_auth_token":'||to_json(p_email_auth_token)||'}';
		end if;
	end if;

	l_reg_URL_qr_base 	= '';
	l_qr_data.url_path 	= '';
	l_qr_data.qr_id 	= '';
	l_qr_data.qr_enc_id = '';
	l_otk_list			= '';

	if l_use_2fa = 'yes' then

		l_reg_URL_qr_base = s_get_config_item( 'register.URL_qr_base', l_customer_id, 'http://auth.simple-auth.com/' );
		l_qr_data = s_get_qr_data(l_id, l_2fa_unique_id);

		-- ------- -- ------- -- ------- -- ------- -- ------- -- ------- -- ------- -- -------
		-- Need to take the p_email_auth_token and convert this into
		-- 1. the QR code for setting up 2fa
		-- 2. the 307 redirect to the setup page /setup-2fa.html?qr=URI&x2fa_id=7777777
		-- 3. Implement the file
		-- 4. The backup HTML from this call in case no 307 redirect takes place.
		-- 	  a. HTML Page
		-- 	  b. JS on page to do a client side redirect
		-- ------- -- ------- -- ------- -- ------- -- ------- -- ------- -- ------- -- -------

		-- https://github.com/jung-kurt/gofpdf/blob/master/fpdf_test.go
		-- Wed Mar 20 14:01:38 MDT 2019
		-- 307 Redirect to based on 2fa setup.

		select "user_id", string_agg("one_time_key",',') as "all_otk"
			into l_junk, l_otk_list
			from "t_2fa_otk"
			where "user_id" = l_id
			group by 1
		;
	end if;

	
	l_94_days = s_get_config_item( 'acct.auth_token.expire', l_customer_id, '94 days');

	-- ,	( '1', 'XSRF.token', 'per-user' )	-- or 'progressive-hashed' or 'off'
    l_xsrf_mode = s_get_xsrf_mode(l_customer_id);
	if l_xsrf_mode = 'per-user' or l_xsrf_mode = 'progressive-hashed' then
		l_xsrf_token = uuid_generate_v4();
	else
		l_xsrf_token = 'n/a';
	end if;

	if not l_fail then	
		l_auth_token = uuid_generate_v4();
		l_seq = uuid_generate_v4();
		insert into "t_auth_token" (
			  "auth_token"	
			, "user_id"	
			, "expire"
		) values (
			  l_auth_token
			, l_id
			, current_timestamp + l_94_days::interval
		);

		--	, current_timestamp + interval '94 days'
		update "t_user"
			set "email_confirmed" = 'y'
				, "ip" = p_ip_addr
				, "email_reset_key" = null
			where "id" = l_id
			;

		if p_method = 'GET' then
			l_redir = ', "$redirect_to$":'||to_json(l_redirect_to);
		else -- if p_method = "POST" then
			l_redir = '';
		end if;

		l_data = '{"status":"success"'
			||', "auth_token":'||to_json(l_auth_token)
			||', "privs":'||to_json(l_privs)
			||', "user_id":'||to_json(l_id)
			||', "redir_to_app":'||to_json(l_redirect_to_app)
			||', "customer_id":'||to_json(l_customer_id)
			||', "use_2fa":'||to_json(l_use_2fa)					-- 2fa Post Process - Setup2FA Post Process
			||', "x2fa_unique_id":'||to_json(l_2fa_unique_id)
				||', "otk_list":'||to_json(s_nvl(l_otk_list))			-- List of 1 time keys
				||', "URL_qr_base":'||to_json(l_reg_URL_qr_base)
				||', "QRImgURL":'||to_json(l_qr_data.url_path)
				||', "qr_id":'||to_json(l_qr_data.qr_id)
				||', "qr_enc_id":'||to_json(l_qr_data.qr_enc_id)
			||', "config":'||to_json(l_config)
			||', "xsrf_token":'||to_json(l_xsrf_token)
			||', "$JWT-claims$":["auth_token"]'
			||', "$session$":{'
				||'"set":['
					||'{"path":["user","$is_logged_in$"],"value":"y"}'
					||',{"path":["user","$xsrf_token$"],"value":'||to_json(l_xsrf_token)||'}'
				||']'
			||'}'
			||l_redir
			||'}';
	end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;
