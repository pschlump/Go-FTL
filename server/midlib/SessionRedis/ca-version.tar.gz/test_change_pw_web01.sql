
select s_change_password ( 'bobob4', 'bobob4', '123456', 'c850b500-6555-492c-aa60-483ff352aa48', '1.1.1.1', 'http://auth.2c-why.com' );

