





alter table "v1_ranch_name" add column "user_id"		char varying (40) ;

alter table "v1_ranch_name" add column "primary_phone"		text;
alter table "v1_ranch_name" add column "address_ship"		text;
alter table "v1_ranch_name" add column "address_usps"		text;
alter table "v1_ranch_name" add column "note"				text;

delete from "t_address_type" ;
insert into "t_address_type" ( "address_type" ) values
	( 'Physical Address' )
,	( 'USPS Address' )
,	( 'Primary Address' )
;

-- CREATE TABLE "t_reg_info" (
alter table "t_reg_info" add column "primary_phone"		text;
alter table "t_reg_info" add column "address_ship"		text;
alter table "t_reg_info" add column "address_usps"		text;
alter table "t_reg_info" add column "note"				text;
alter table "t_reg_info" add column "records_for_3_years" 		char varying(1) not null default 'y';
alter table "t_reg_info" add column "records_secure"			char varying(1) not null default 'y';
alter table "t_reg_info" add column "n_calvs_in_program"		bigint;
alter table "t_reg_info" add column "calvs_born_in_wy"			char varying(1) not null default 'y';
alter table "t_reg_info" add column "calvs_born_locations" 		text;
alter table "t_reg_info" add column "calvs_individual_dates"	char varying(1) not null default 'y';
alter table "t_reg_info" add column "calvs_moved_off_ranch"		char varying(1) not null default 'y';
alter table "t_reg_info" add column "calvs_moved_desc"			text;
alter table "t_reg_info" add column "calvs_purchased_onsite"	char varying(1) not null default 'y';
alter table "t_reg_info" add column "calvs_purchased_desc"		text;
alter table "t_reg_info" add column "calvs_purchased_ident"		text;
alter table "t_reg_info" add column "when_apply_tags"			char varying(50) not null default 'Calving';
alter table "t_reg_info" add column "signature_name"			text;
alter table "t_reg_info" add column "signature_digital"			text;
alter table "t_reg_info" add column "signature_date"			text;
alter table "t_reg_info" add column "signature_file"			text;

alter table "t_reg_info" add column "real_name"			text;
alter table "t_reg_info" add column 
  "kept_3_years"	char varying(1) not null default 'y' check ( "kept_3_years" in ( 'y', 'n' ) );
alter table "t_reg_info" add column 
  "secure_rec"		char varying(1) not null default 'y' check ( "secure_rec" in ( 'y', 'n' ) );

alter table "t_paper_docs" add column "txid"			text;

-- stmt = `update "t_reg_info" set "signature_file" = $2, signature_uri = $3 where "id" = $1`
alter table "t_reg_info" add column "signature_uri"			text;
