
select s_login('test01', 'bobob4',  '1.1.1.1',  'http://www.2c-why.com/' );

