
-- "Copyright (C) Philip Schlump, 2009-2017." 

m4_include(types.m4)

-- drop table "t_user" ;
-- alter table "t_user" add column  "user_attr" 			text default '{}'	;
-- alter table "t_user" add column  "x2fa_id"				char varying (40) ;
-- alter table "t_2fa" add column  "qr_id"					char varying (40) ;
-- alter table "t_2fa" add column  "fpfull"				text;

CREATE TABLE "t_user" (
	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
	, "username"			text not null
	, "password"			text not null
  	, "ip" 					char varying (40) not null			 						
	, "real_name"			text not null
	, "email_address"		text not null
	, "email_confirmed"		char (1) default 'n' not null check ( "email_confirmed" in ( 'y', 'n' ) )
	, "acct_state"			char varying (10) not null default 'unknown' check ( "acct_state" in ( 'unknown', 'locked', 'ok', 'pass-reset', 'billing', 'closed', 'fixed', 'temporary', '2fa-pend' ) )
	, "default_priority"	int default 10 														-- 10 is standard priority ( higher is higher, lower is lower )
	, "acct_expire"			timestamp
	, "n_login_fail"		int default 0 not null
	, "login_fail_delay"	timestamp
	, "email_reset_key"		char varying (80) 
	, "email_reset_timeout" timestamp 		 													-- 
	, "password_set_date" 	timestamp 		 													-- 
	, "dflt_priority"		int default 10 not null												-- 10 is standard priority ( higher is higher, lower is lower )
	, "last_login" 			timestamp 		 													-- 
  	, "privs" 				text default '[]'													-- JSON of privilate set, empty means testing login
  	, "user_attr" 			text default '{}'													-- User specified attributes
	, "customer_id"			char varying (40) default '1'
	, "x2fa_id"				char varying (40) 
	, "updated" 			timestamp 									 						-- Project update timestamp (YYYYMMDDHHMMSS timestamp).
	, "created" 			timestamp default current_timestamp not null 						-- Project creation timestamp (YYYYMMDDHHMMSS timestamp).
);

create unique index "t_user_u1" on "t_user" ( "auth_token" );
create unique index "t_user_u2" on "t_user" ( "email_address" );
create unique index "t_user_u3" on "t_user" ( "email_reset_key" );
create unique index "t_user_u4" on "t_user" ( "username" );

m4_updTrig(t_user)

---------------------------------------------------------------------------------------------------------------
-- list of setup and validated devices
---------------------------------------------------------------------------------------------------------------

drop table "t_2fa" ;
drop table "t_2fa_otk" ;

CREATE TABLE "t_2fa" (
	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
	, "user_id"				m4_uuid_type() not null
	, "user_hash"			text 
	, "fp"					text 
	, "fpfull"				text 
	, "qr_id"				text
	, "updated" 			timestamp 									 						
	, "created" 			timestamp default current_timestamp not null 					
);

create index "t_2fa_p1" on "t_2fa" ( "user_id" );
create index "t_2fa_p2" on "t_2fa" ( "user_hash" );

m4_updTrig(t_2fa)

---------------------------------------------------------------------------------------------------------------
-- list of user one time keys
---------------------------------------------------------------------------------------------------------------

CREATE TABLE "t_2fa_otk" (
	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
	, "user_id"				m4_uuid_type() not null
	, "one_time_key"		text
	, "updated" 			timestamp 									 						
	, "created" 			timestamp default current_timestamp not null 					
);

create index "t_2fa_otk_p1" on "t_2fa_otk" ( "user_id" );

m4_updTrig(t_2fa_otk)
