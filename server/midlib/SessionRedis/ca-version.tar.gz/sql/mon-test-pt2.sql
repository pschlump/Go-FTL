
select ping_i_am_alive( 'bob', '127.0.0.1', 'hi there ' );

