\i tables-pg.sql
\i auth.sql
\i t_config_data.sql
\i t_monitor_stuff.sql
\i new.sql
