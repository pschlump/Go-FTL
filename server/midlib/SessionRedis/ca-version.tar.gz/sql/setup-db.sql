
--
-- Remember to
--
-- 		$ sudo apt-get install postgresql-contrib-9.3
--
-- Before running this.
--

CREATE EXTENSION "uuid-ossp";
CREATE EXTENSION pgcrypto;
CREATE EXTENSION json_accessors;

