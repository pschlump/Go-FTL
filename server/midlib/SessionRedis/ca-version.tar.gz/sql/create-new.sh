
wget  -o ,test-step1-o1.out -O ,test-step1-o2.out 'http://192.168.0.182:8090/api/ping_i_am_alive?item=TestOfWhoCares&note=Test'
#                                                                           /api/ping_i_am_alive?item=InternetUp&note=Ok

