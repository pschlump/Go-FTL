
\i t_config.sql
\i t_customer.sql
\i t_user.sql
\i t_ip_ban.sql
\i t_host_to_customer.sql
\i t_auth_token.sql
\i t_user.sql
\i s_login.sql
\i s_register_new_user.sql
\i s_logout.sql
\i s_confirm_email.sql
\i s_password_reset.sql
\i s_change_password.sql
