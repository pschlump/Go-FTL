
select s_register_immediate(
	  'abc' -- p_username varchar
	, 'abc' -- p_password varchar
	, 'abc' -- p_again varchar
	, '127.0.0.1' -- p_ip_addr varchar
	, 'abc@abc.def' -- p_email varchar
	, 'Already Been Chewed' -- p_real_name varchar
	, 'Chewed Ranch' -- p_ranch_name varchar
	, 'http://127.0.0.1:9019' -- p_url varchar
	, 'app.beefchain.com' -- p_app varchar
	, 'POST' -- p_method varchar
);

