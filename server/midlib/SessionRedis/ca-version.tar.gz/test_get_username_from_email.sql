
-- CREATE or REPLACE FUNCTION s_get_username_from_email(p_email_address varchar, p_ip_addr varchar, p_url varchar)

select s_get_username_from_email( 'kermit.nosend.01@gmail.com','1.1.1.1', 'http://www.2c-why.com/' );

