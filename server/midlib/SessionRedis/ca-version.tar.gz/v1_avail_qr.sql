






-- "Copyright (C) Philip Schlump, 2016."








CREATE SEQUENCE t_qr_set_seq
  INCREMENT 1
  MINVALUE 24
  MAXVALUE 9223372036854775807
  START 24
  CACHE 1;

CREATE SEQUENCE t_qr_avail_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;

-- drop TABLE "t_avail_qr" ;

CREATE TABLE "t_avail_qr" (
	  "id"					m4_uuid_type() DEFAULT uuid_generate_v4() not null primary key
	, "file_name"			text
	, "url_path"			text
	, "file_name_nbr"		text	-- non branded QR code.
	, "url_path_nbr"		text
	, "qr_id"				text
	, "qr_enc_id"			text
	, "state"				char varying (10) check ( "state" in ( 'avail', 'used', 's1', 's2' ) ) default 'avail' not null
	, "ord_seq"				bigint DEFAULT nextval('t_qr_avail_seq'::regclass) NOT NULL
	, "updated" 			timestamp
	, "created" 			timestamp default current_timestamp not null
);

create index "t_avail_qr_p1" on "t_avail_qr" ( "state", "ord_seq" );
create unique index "t_avail_qr_u1" on "t_avail_qr" ( "qr_id" );
create unique index "t_avail_qr_u2" on "t_avail_qr" ( "qr_enc_id" );



CREATE OR REPLACE function t_avail_qr_upd()
RETURNS trigger AS 
$BODY$
BEGIN
  NEW.updated := current_timestamp;
  RETURN NEW;
END
$BODY$
LANGUAGE 'plpgsql';


CREATE TRIGGER t_avail_qr_trig
BEFORE update ON "t_avail_qr"
FOR EACH ROW
EXECUTE PROCEDURE t_avail_qr_upd();





drop FUNCTION s_get_qr_json(p_type varchar);

CREATE or REPLACE FUNCTION s_get_qr_json(p_type varchar)
	RETURNS varchar AS $$
DECLARE
	l_data				varchar (800);
	l_debug_on			bool;
	l_file_name			varchar (100);
	l_url_path			varchar (100);
	l_file_name_nbr		varchar (100);
	l_url_path_nbr		varchar (100);
	l_qr_id				varchar (20);
	l_qr_enc_id			varchar (20);
	l_id				varchar (40);
BEGIN

	-- "Copyright (C) Philip Schlump, 2017." 

	l_data = '{"status":"success"}';
	l_debug_on = s_debug_flag_enabled( 's_get_qr_json' );

	select 
			  "id"
			, "file_name"			
			, "url_path"		
			, "file_name_nbr"
			, "url_path_nbr"		
			, "qr_id"			
			, "qr_enc_id"	
		into
			  l_id
			, l_file_name			
			, l_url_path		
			, l_file_name_nbr
			, l_url_path_nbr
			, l_qr_id	
			, l_qr_enc_id			
		from "t_avail_qr"
		where "state" = 'avail'
		limit 1
		;

	l_data = '{'
			||'  "file_name":' || to_json(s_nvl(l_file_name))
			||', "url_path":' || to_json(s_nvl(l_url_path))
			||', "file_name_nbr":' || to_json(s_nvl(l_file_name_nbr))
			||', "url_path_nbr":' || to_json(s_nvl(l_url_path_nbr))
			||', "qr_id":' || to_json(s_nvl(l_qr_id))
			||', "qr_enc_id":' || to_json(s_nvl(l_qr_enc_id))
		||'}';

	update "t_avail_qr"
		set "state" = 'used'
		where "id" = l_id
	;

	-- if l_debug_on then
	-- 	insert into "t_output" ( "output" ) values ( ' "cleanup of failed register":'||to_json(p_user_id)||' user_id='||to_json(p_username) );
	-- end if;

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;




drop FUNCTION s_get_qr(p_type varchar);

CREATE or REPLACE FUNCTION s_get_qr(p_type varchar)
	RETURNS qr_type AS $$
DECLARE
	result_record qr_type;
	l_debug_on			bool;
BEGIN

	-- "Copyright (C) Philip Schlump, 2017." 

	l_debug_on = s_debug_flag_enabled( 's_get_qr_json' );

	select 
			  "id"
			, "file_name"			
			, "url_path"		
			, "file_name_nbr"
			, "url_path_nbr"		
			, "qr_id"			
			, "qr_enc_id"	
		into
			  result_record.id
			, result_record.file_name			
			, result_record.url_path		
			, result_record.file_name_nbr
			, result_record.url_path_nbr
			, result_record.qr_id	
			, result_record.qr_enc_id			
		from "t_avail_qr"
		where "state" = 'avail'
		limit 1
		;

	update "t_avail_qr"
		set "state" = 'used'
		where "id" = result_record.id
	;

	-- if l_debug_on then
	-- 	insert into "t_output" ( "output" ) values ( ' "cleanup of failed register":'||to_json(p_user_id)||' user_id='||to_json(p_username) );
	-- end if;

	RETURN result_record;
END;
$$ LANGUAGE plpgsql;



drop FUNCTION s_get_qr_data(p_user_id varchar, p_x2fa_unique_id varchar);

CREATE or REPLACE FUNCTION s_get_qr_data(p_user_id varchar, p_x2fa_unique_id varchar)
	RETURNS qr_type AS $$
DECLARE
	result_record qr_type;
	l_debug_on			bool;
BEGIN

	-- "Copyright (C) Philip Schlump, 2017." 

	l_debug_on = s_debug_flag_enabled( 's_get_qr_json' );

	select 
			  "id"
			, "file_name"			
			, "url_path"		
			, "file_name_nbr"
			, "url_path_nbr"		
			, "qr_id"			
			, "qr_enc_id"	
		into
			  result_record.id
			, result_record.file_name			
			, result_record.url_path		
			, result_record.file_name_nbr
			, result_record.url_path_nbr
			, result_record.qr_id	
			, result_record.qr_enc_id			
		from "t_avail_qr"
		where "qr_id" = ( 
			select "qr_id"
			from "t_2fa"
			where "id" = p_x2fa_unique_id
			  and "user_id" = p_user_id
			)
		limit 1
		;

	-- if l_debug_on then
	-- 	insert into "t_output" ( "output" ) values ( ' "cleanup of failed register":'||to_json(p_user_id)||' user_id='||to_json(p_username) );
	-- end if;

	RETURN result_record;
END;
$$ LANGUAGE plpgsql;


