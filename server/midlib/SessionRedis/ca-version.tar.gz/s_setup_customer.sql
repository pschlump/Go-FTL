





-- "Copyright (C) Philip Schlump, 2009-2017." 

-- Setup or reset a customer id to it's original configuration.


-- drop SEQUENCE t_email_id_seq;

CREATE SEQUENCE t_customer_id_seq
  INCREMENT 1
  MINVALUE 1000
  MAXVALUE 9223372036854775807
  START 1000
  CACHE 1;


drop FUNCTION s_setup_customer ( p_ip_addr varchar );
drop FUNCTION s_setup_customer ( p_ip_addr varchar, p_customer_id varchar );

CREATE or REPLACE FUNCTION s_setup_customer ( p_ip_addr varchar, p_customer_id varchar )
	RETURNS varchar AS $$

DECLARE
	l_data				varchar (100);
	l_fail				bool;
	l_customer_id		bigint;

BEGIN
	-- "Copyright (C) Philip Schlump, 2009-2017." 

	if p_customer_id is null then
		select nextval('t_customer_id_seq'::regclass) 
			into l_customer_id;
		p_customer_id = l_customer_id::text;
	else
	end if;

	delete from "t_config" 
		where "customer_id" = p_customer_id
	;

	insert into "t_config" ( "customer_id", "item_name", "value" ) values
			( p_customer_id, 'from.address', 'pschlump@gmail.com' )
		,	( p_customer_id, 'debug.status.1', 'on' )
		,	( p_customer_id, 'acct.auth_token.expire', '94 days' )
		,	( p_customer_id, 'email.confirm.is.login', 'no' )
		,	( p_customer_id, 'register.redirect.to', '/setup-2fa.html?qr={{.x1}}&x2fa_id={{.x2}}' )			-- PJS New
		,	( p_customer_id, 'register.redirect.to.app', 'http://localhost:3000/newly-registered' )
		,	( p_customer_id, 'recover.redirect.to', 'http://localhost:3000/recover-password-pt2' )
		,	( p_customer_id, 'recover.redirect.to.old', '/recover-password.html' )
		,	( p_customer_id, 'XSRF.token', 'per-user' )		-- or 'progressive-hashed' or 'off'
		,	( p_customer_id, 'username.is.email', 'no' )	-- username is the email.  - email address value will be overwritten with 'username'
		,	( p_customer_id, '2fa.required', 'yes' )		-- yes/no - if yes then login is not finished unilt 2fa "pin" is provided.
		,	( p_customer_id, 'immediate.register', 'yes' )	
		,	( p_customer_id, 'email-conf.register', 'yes' )
		,	( p_customer_id, 'setup_from', p_ip_addr )
		,	( p_customer_id, 'register.email_template', 'register_email.tmpl' )
		,	( p_customer_id, 'register.PATH_template', './tmpl' )
		,	( p_customer_id, 'register.URL_2fa_setup', 'http://auth.simple-auth.com/2fasetup' )
		,	( p_customer_id, 'register.URL_qr_base', 'http://auth.simple-auth.com/qr/' )
		,	( p_customer_id, 'register.PATH_qr_base', './qr' )
		,	( p_customer_id, 'register.URL_2fa_app', 'http://2fa.simple-auth.com/' )
		,	( p_customer_id, 'register.URL_kick', 'http://email.simple-auth.com/kick' )
	;
	-- use - URL for Email Template
	-- use - URL for 2fa setup Template
	-- use - URL for QR Code to setup 2fa
	insert into "t_config" ( "customer_id", "item_name", "value", "i_value" ) values
			( p_customer_id, 'ttl.user.auth_token', '', 180 )
	;

	delete from "t_customer"
		where "id" = p_customer_id
	;

	insert into "t_customer" ( "id", "name" ) values ( p_customer_id, 'test-customer' );

	delete from  "t_host_to_customer"
		where "customer_id" = p_customer_id
	;

	insert into "t_host_to_customer" ( "customer_id", "host_name" ) values
			( p_customer_id, 'http://www.2c-why.com' )
		,	( p_customer_id, 'http://auth.2c-why.com' )
		,	( p_customer_id, 'http://www.2c-why.com/' )
		,	( p_customer_id, 'http://auth.2c-why.com/' )
	;

	-- is_localhost set for testing APIs --
	-- Like: validate auth_token key
	-- insert into "t_host_to_customer" ( "customer_id", "host_name", "is_localhost" ) values
	-- 		( p_customer_id, 'http://localhost:9001', 'yes' )
	-- 	, 	( p_customer_id, 'http://localhost:9001/', 'yes' )
	-- 	, 	( p_customer_id, 'http://127.0.0.1:9001', 'yes' )
	-- 	, 	( p_customer_id, 'http://127.0.0.1:9001/', 'yes' )
	-- 	,	( p_customer_id, 'http://localhost:9019', 'yes' )
	-- 	, 	( p_customer_id, 'http://localhost:9019/', 'yes' )
	-- 	, 	( p_customer_id, 'http://127.0.0.1:9019', 'yes' )
	-- 	, 	( p_customer_id, 'http://127.0.0.1:9019/', 'yes' )
	-- ;

	l_data = '{"status":"success"'
		||', "customer_id":'||to_json(p_customer_id)
		||'}';

	RETURN l_data;
END;
$$ LANGUAGE plpgsql;



