
select s_password_reset_pt2 ( '08c8671f-b363-47b8-89aa-04b771aeccc0', '1.1.1.1', 'http://auth.2c-why.com' );

