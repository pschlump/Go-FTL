





-- "Copyright (C) Philip Schlump, 2009-2017." 

drop TABLE dual ;
CREATE TABLE dual (
	  x	text
);
delete from dual;
insert into dual ( x ) values ( 'y' );

