
\i s_register_canada.sql
