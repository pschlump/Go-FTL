
select s_logout( 'dd0f9b34-fd8c-4740-a11b-82ccd49aae15', '1.1.1.1');

