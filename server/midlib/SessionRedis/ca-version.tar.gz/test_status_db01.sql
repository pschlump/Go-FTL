
select status_db ( '1.1.1.1' );

