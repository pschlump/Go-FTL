
select s_confirm_email ( 'b700785f-aeae-48ba-89cd-bf61759d5ce0', '1.1.1.1', 'http://www.2c-why.com', 'GET'  );

