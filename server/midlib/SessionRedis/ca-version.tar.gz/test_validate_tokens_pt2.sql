
select s_validate_token( 'bobob4', 'ee1d2eb2-1deb-4d0e-a93f-3ad742f12c1f' );

