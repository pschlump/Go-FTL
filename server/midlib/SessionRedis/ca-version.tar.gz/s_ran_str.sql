





drop function random_string(length integer);

CREATE or REPLACE function random_string(length integer) returns text as
$$
declare
  chars text[] := '{0,1,2,3,4,5,6,7,8,9}';
  result text := '';
  i integer := 0;
begin
  if length < 0 then
    raise exception 'Given length cannot be less than 0';
  end if;
  for i in 1..length loop
    result := result || chars[1+random()*(array_length(chars, 1)-1)];
  end loop;
  return result;
end;
$$ language plpgsql;

select random_string(8);




drop function s_setup_2fa_tables(p_2fa_id varchar, p_user_id varchar, p_hash varchar);
drop function s_setup_2fa_tables(p_2fa_id varchar, p_user_id varchar, p_hash varchar, p_qr_id varchar);

CREATE or REPLACE function s_setup_2fa_tables(p_2fa_id varchar, p_user_id varchar, p_hash varchar, p_qr_id varchar)
	returns text as
$$
DECLARE
 	l_rstr varchar(20);
BEGIN
	delete from "t_2fa_otk" where "user_id" = p_user_id;
	delete from "t_2fa" where "user_id" = p_user_id;

	insert into "t_2fa" ( "id", "user_id", "user_hash", "qr_id" ) values ( p_2fa_id::uuid, p_user_id::uuid, p_hash, p_qr_id );
	--insert into "t_2fa_otk" ( "id", "user_id", "one_time_key" )
	--	select uuid_generate_v4(), p_user_id::uuid, random_string(18)
	--	from generate_series(1,20);
	-- select random_string(15) from generate_series(1,15);
	for i in 1..20 loop
	 	select random_string(8) into l_rstr;
	 	insert into "t_2fa_otk" ( "user_id", "one_time_key" ) values ( p_user_id, l_rstr );
	end loop;
	return '{"status":"success"}';
END;
$$ language plpgsql;

-- select s_setup_2fa_tables('901efa49-0484-4411-7433-f25c586d4274',  '901efa49-0484-4411-7433-f25c586d4274',  '444' );
-- select * from t_2fa;
-- select * from t_2fa_otk;
-- select s_setup_2fa_tables('901efa49-0484-4411-7433-f25c586d4274',  '901efa49-0484-4411-7433-f25c586d4274',  '444' );

