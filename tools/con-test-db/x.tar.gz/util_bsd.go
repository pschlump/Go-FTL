// code for BSD

// +build darwin dragonfly freebsd netbsd openbsd

package main

var IsWindows = false
var IsBSD = true
var IsLinux = false
var IsUnix = true

/*
	,"connectToPostgreSQL":"user=postgres password=f1ref0x2 dbname=test port=5433 host=192.168.0.151"
	,"connectToDbType":"postgres"
	,"connectToDbName":"postgres(192.168.0.157:5433)"
*/
