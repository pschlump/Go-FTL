// code dedicated to windows

// +build windows

package main

var IsWindows = true
var IsBSD = false
var IsLinux = false
var IsUnix = false
