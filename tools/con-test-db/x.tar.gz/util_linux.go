// code for linux

package main

var IsWindows = false
var IsBSD = false
var IsLinux = true
var IsUnix = true
