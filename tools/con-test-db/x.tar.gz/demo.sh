
./con-test-db -C "user=postgres dbname=pschlump port=5432 host=127.0.0.1 sslmode=disable"
