create table "xyzzy" (
	"id" int
);

insert into "xyzzy" ( "id" ) values ( 1 );

